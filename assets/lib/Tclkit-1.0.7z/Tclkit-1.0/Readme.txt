Do not add the patch number to the tcl and tk directories.
Otherwise the kbskit Makefile won't work correctly.
